# rclcpp examples

This directory contains many examples of how to do common tasks with rclcpp.
The intent is that this material will be easy to copy-and-paste into your own projects.
